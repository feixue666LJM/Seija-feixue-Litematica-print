/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.seija.printer.print_main.printer.block_fixer.fixers.click_fixer;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.ComparatorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

public class RSTComparatorFixer extends AbstractClickFixer{
    public RSTComparatorFixer() {
        super("ComparatorFix");
    }

    @Override
    public boolean needFix(BlockPos pos, BlockState needState) {
        if (!super.needFix(pos,needState)) {
            return false;
        }
        BlockState blockState = mc.level.getBlockState(pos);
        if (
            blockState.getBlock() instanceof ComparatorBlock&&needState.getBlock()==blockState.getBlock()) {
            return blockState.getValue(BlockStateProperties.MODE_COMPARATOR) != needState.getValue(BlockStateProperties.MODE_COMPARATOR);
        }
        return false;
    }
}
